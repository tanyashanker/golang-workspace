package main

import (
	"encoding/json"
	"log"
	"fmt"
	"net/http"
	"github.com/labstack/echo"
	"LeadMgmt/ev_lm_json"
)

func jsonDecode(c echo.Context) error {
	lead := ev_lm_json.Lead{}
	defer c.Request().Body.Close()
	err := json.NewDecoder(c.Request().Body).Decode(&lead)
	if err != nil{
		log.Printf("Failed processing request body in lead body : %s", err)
		return echo.NewHTTPError(http.StatusInternalServerError) //sends error object with help of echo package
	}
	log.Printf("this is decoded json object: %s",lead) //here you can added it to database
	return c.String(http.StatusOK,fmt.Sprintf("%s", lead))

}


func jsonEncode(c echo.Context) error {

	user := &ev_lm_json.User{
		Id : "1",
    	Username : "username",
    	FirstName : "firstname",
    	LastName : "lastname",
    	Phone : "9876543210",
    	Email : "email@eagleview.com",
    	Address : "address",
    	UserStatus : "false",
	} 
	
	lead := &ev_lm_json.Lead{
		Id : "1",
    	Users : []ev_lm_json.User{*user},
    	Name : "leadName",
    	RepairType : "repairName", 	
    	Address	: "leadAddress",
    	Status : "leadStatus",
	}

	c.Response().Header().Set(echo.HeaderContentType, echo.MIMEApplicationJSONCharsetUTF8)
  	c.Response().WriteHeader(http.StatusOK)
  	return json.NewEncoder(c.Response()).Encode(lead)
}

func main() {
	e := echo.New()
	e.POST("/jsonDecode", jsonDecode)
	e.GET("/jsonEncode", jsonEncode)
	e.Start(":8099")
}