package ev_lm_json


type User struct {
    Id  string             `json:"id"`
    Username    string  `json:"username"`
    FirstName	string  `json:"firstName"`
    LastName	string  `json:"lastName"`
    Phone	string      `json:"phone"`
    Email	string      `json:"email"`
    Address	string      `json:"address"`
    UserStatus	string 	`json:"userStatus"`
}

type Lead struct {
    Id string              `json:"id"`
    Users []User        `json:"user"`
    Name string         `json:"name"`
    RepairType	string  `json:"repairType"`
    Address	string      `json:"address"`
    Status string       `json:"status"`
}

type ApiResponse struct {
	Code int 		`json:"code"`
    Type string 		`json:"type"`
    Message string 		`json:"message"`
}